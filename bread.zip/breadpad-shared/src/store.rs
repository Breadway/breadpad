use crate::types::Note;
use anyhow::{Context, Result};
use chrono::{Duration, Utc};
use std::fs::{self, OpenOptions};
use std::io::{BufRead, BufReader, Write};
use std::path::{Path, PathBuf};

pub struct Store {
    notes_path: PathBuf,
    archive_path: PathBuf,
}

impl Store {
    pub fn new() -> Result<Self> {
        let data_dir = dirs::data_local_dir()
            .context("no XDG data dir")?
            .join("breadpad");
        Self::from_dir(&data_dir)
    }

    pub fn from_dir(dir: &Path) -> Result<Self> {
        fs::create_dir_all(dir)?;
        Ok(Store {
            notes_path: dir.join("notes.jsonl"),
            archive_path: dir.join("archive.jsonl"),
        })
    }

    pub fn load_all(&self) -> Result<Vec<Note>> {
        self.load_from(&self.notes_path)
    }

    pub fn load_archive(&self) -> Result<Vec<Note>> {
        self.load_from(&self.archive_path)
    }

    fn load_from(&self, path: &Path) -> Result<Vec<Note>> {
        if !path.exists() {
            return Ok(Vec::new());
        }
        let file = fs::File::open(path)?;
        let reader = BufReader::new(file);
        let mut notes = Vec::new();
        for (i, line) in reader.lines().enumerate() {
            let line = line?;
            let trimmed = line.trim();
            if trimmed.is_empty() {
                continue;
            }
            match serde_json::from_str::<Note>(trimmed) {
                Ok(note) => notes.push(note),
                Err(e) => tracing::warn!("skipping malformed note at line {}: {}", i + 1, e),
            }
        }
        Ok(notes)
    }

    pub fn save_note(&self, note: &Note) -> Result<()> {
        let mut file = OpenOptions::new()
            .create(true)
            .append(true)
            .open(&self.notes_path)?;
        let line = serde_json::to_string(note)?;
        writeln!(file, "{}", line)?;
        Ok(())
    }

    pub fn update_note(&self, updated: &Note) -> Result<()> {
        self.rewrite_notes(|note| {
            if note.id == updated.id {
                updated.clone()
            } else {
                note
            }
        })
    }

    pub fn delete_note(&self, id: &str) -> Result<()> {
        let notes: Vec<Note> = self.load_all()?.into_iter().filter(|n| n.id != id).collect();
        self.write_all(&self.notes_path, &notes)
    }

    fn rewrite_notes<F>(&self, mut f: F) -> Result<()>
    where
        F: FnMut(Note) -> Note,
    {
        let notes: Vec<Note> = self.load_all()?.into_iter().map(|n| f(n)).collect();
        self.write_all(&self.notes_path, &notes)
    }

    fn write_all(&self, path: &Path, notes: &[Note]) -> Result<()> {
        let tmp_path = path.with_extension("tmp");
        {
            let mut file = fs::File::create(&tmp_path)?;
            for note in notes {
                let line = serde_json::to_string(note)?;
                writeln!(file, "{}", line)?;
            }
            file.flush()?;
        }
        fs::rename(&tmp_path, path)?;
        Ok(())
    }

    pub fn rotate_archive(&self, archive_after_days: i64) -> Result<usize> {
        let cutoff = Utc::now() - Duration::days(archive_after_days);
        let notes = self.load_all()?;
        let (to_archive, keep): (Vec<Note>, Vec<Note>) = notes
            .into_iter()
            .partition(|n| n.done && n.completed.map_or(false, |c| c < cutoff));

        if to_archive.is_empty() {
            return Ok(0);
        }

        let count = to_archive.len();
        let mut archive_file = OpenOptions::new()
            .create(true)
            .append(true)
            .open(&self.archive_path)?;
        for note in &to_archive {
            writeln!(archive_file, "{}", serde_json::to_string(note)?)?;
        }

        self.write_all(&self.notes_path, &keep)?;
        Ok(count)
    }

    pub fn get_by_id(&self, id: &str) -> Result<Option<Note>> {
        Ok(self.load_all()?.into_iter().find(|n| n.id == id))
    }
}
