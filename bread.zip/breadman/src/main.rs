use anyhow::Result;
use breadpad_shared::{
    config::Config,
    store::Store,
    theme::{build_css, load_palette},
    types::{Note, NoteType},
};
use gtk4::{glib, prelude::*};
use std::cell::RefCell;
use std::rc::Rc;
use std::sync::Arc;

mod editor;
mod views;

mod args {
    #[derive(Debug)]
    pub struct Args {
        pub view: Option<String>,
        pub done_id: Option<String>,
        pub upcoming_plain: bool,
    }

    pub fn parse() -> Args {
        let mut args = Args {
            view: None,
            done_id: None,
            upcoming_plain: false,
        };
        let raw: Vec<String> = std::env::args().skip(1).collect();
        let mut i = 0;
        while i < raw.len() {
            match raw[i].as_str() {
                "--view" | "-v" => {
                    i += 1;
                    args.view = raw.get(i).cloned();
                }
                "done" => {
                    i += 1;
                    args.done_id = raw.get(i).cloned();
                }
                "upcoming" => {
                    if raw.get(i + 1).map(|s| s.as_str()) == Some("--plain") {
                        args.upcoming_plain = true;
                        i += 1;
                    }
                    args.view = Some("upcoming".into());
                }
                _ => {}
            }
            i += 1;
        }
        args
    }
}

fn main() -> Result<()> {
    tracing_subscriber::fmt()
        .with_env_filter(
            tracing_subscriber::EnvFilter::from_default_env()
                .add_directive("breadman=info".parse().unwrap()),
        )
        .init();

    let args = args::parse();
    let cfg = Config::load()?;

    if let Some(id) = &args.done_id {
        return cmd_done(id);
    }

    if args.upcoming_plain {
        return cmd_upcoming_plain();
    }

    run_app(args.view, cfg)
}

fn cmd_done(id: &str) -> Result<()> {
    let store = Store::new()?;
    let note = match store.get_by_id(id)? {
        Some(n) => n,
        None => anyhow::bail!("note {} not found", id),
    };
    let mut updated = note;
    updated.mark_done();
    store.update_note(&updated)?;
    println!("marked {} as done", id);
    Ok(())
}

fn cmd_upcoming_plain() -> Result<()> {
    let store = Store::new()?;
    let mut notes: Vec<Note> = store
        .load_all()?
        .into_iter()
        .filter(|n| {
            !n.done
                && matches!(n.note_type, NoteType::Reminder | NoteType::Todo)
                && n.effective_time().is_some()
        })
        .collect();
    notes.sort_by_key(|n| n.effective_time().unwrap());
    for note in &notes {
        let t = note.effective_time().unwrap();
        let local: chrono::DateTime<chrono::Local> = t.into();
        println!("[{}] {} — {}", note.id, local.format("%a %b %d %H:%M"), note.body);
    }
    Ok(())
}

fn run_app(initial_view: Option<String>, cfg: Config) -> Result<()> {
    let app = gtk4::Application::builder()
        .application_id("com.breadway.breadman")
        .build();

    let cfg = Arc::new(cfg);
    let initial_view = Arc::new(initial_view);

    app.connect_activate(move |app| {
        let cfg = cfg.clone();
        let initial_view = initial_view.clone();
        if let Err(e) = build_app_window(app, cfg, initial_view.as_deref().clone()) {
            tracing::error!("failed to build window: {}", e);
        }
    });

    let code = app.run_with_args::<String>(&[]);
    if code != glib::ExitCode::SUCCESS {
        anyhow::bail!("GTK application exited with error");
    }
    Ok(())
}

fn build_app_window(
    app: &gtk4::Application,
    cfg: Arc<Config>,
    initial_view: Option<&str>,
) -> Result<()> {
    apply_css(&cfg);

    let store = Arc::new(Store::new()?);
    let notes: Rc<RefCell<Vec<Note>>> = Rc::new(RefCell::new(store.load_all()?));

    let window = gtk4::ApplicationWindow::builder()
        .application(app)
        .title("breadman")
        .default_width(900)
        .default_height(600)
        .build();

    let hbox = gtk4::Box::builder()
        .orientation(gtk4::Orientation::Horizontal)
        .build();

    // Sidebar
    let sidebar_list = gtk4::ListBox::builder()
        .selection_mode(gtk4::SelectionMode::Single)
        .width_request(180)
        .css_classes(["sidebar"])
        .build();

    let sidebar_items: &[(&str, &str)] = &[
        ("all", "All"),
        ("upcoming", "Upcoming"),
        ("todo", "Todo"),
        ("reminder", "Reminder"),
        ("idea", "Idea"),
        ("note", "Note"),
        ("question", "Question"),
        ("archive", "Archive"),
    ];
    for &(id, label) in sidebar_items {
        let row = gtk4::ListBoxRow::builder()
            .css_classes(["sidebar-row"])
            .build();
        row.set_widget_name(id);
        row.set_child(Some(
            &gtk4::Label::builder().label(label).xalign(0.0).build(),
        ));
        sidebar_list.append(&row);
    }

    // Main area: search + content stack
    let content_vbox = gtk4::Box::builder()
        .orientation(gtk4::Orientation::Vertical)
        .hexpand(true)
        .build();

    let search_entry = gtk4::SearchEntry::builder()
        .placeholder_text("Search notes…")
        .css_classes(["search-entry"])
        .margin_start(8)
        .margin_end(8)
        .margin_top(8)
        .margin_bottom(4)
        .build();

    let stack = gtk4::Stack::builder().hexpand(true).vexpand(true).build();

    content_vbox.append(&search_entry);
    content_vbox.append(&stack);

    hbox.append(&sidebar_list);
    let sep = gtk4::Separator::builder()
        .orientation(gtk4::Orientation::Vertical)
        .build();
    hbox.append(&sep);
    hbox.append(&content_vbox);

    window.set_child(Some(&hbox));

    // Populate stack
    {
        let notes_ref = notes.borrow();
        rebuild_stack(&stack, &notes_ref, store.clone(), "all");
    }

    // Sidebar selection
    {
        let stack_clone = stack.clone();
        let notes_clone = notes.clone();
        let store_clone = store.clone();
        sidebar_list.connect_row_selected(move |_, row| {
            if let Some(row) = row {
                let view = row.widget_name().to_string();
                let notes_ref = notes_clone.borrow();
                rebuild_stack(&stack_clone, &notes_ref, store_clone.clone(), &view);
                stack_clone.set_visible_child_name(&view);
            }
        });
    }

    // Search
    {
        let stack_clone = stack.clone();
        let notes_clone = notes.clone();
        let store_clone = store.clone();
        search_entry.connect_search_changed(move |entry| {
            let query = entry.text().to_string();
            let all_notes = notes_clone.borrow();
            let filtered: Vec<Note> = if query.trim().is_empty() {
                all_notes.clone()
            } else {
                let q = query.to_lowercase();
                all_notes
                    .iter()
                    .filter(|n| n.body.to_lowercase().contains(&q))
                    .cloned()
                    .collect()
            };
            rebuild_stack_with_notes(&stack_clone, &filtered, store_clone.clone(), "all");
            stack_clone.set_visible_child_name("all");
        });
    }

    // Select initial view
    let initial = initial_view.unwrap_or("all");
    for row in sidebar_list
        .observe_children()
        .snapshot()
        .iter()
        .filter_map(|obj| obj.clone().downcast::<gtk4::ListBoxRow>().ok())
    {
        if row.widget_name() == initial {
            sidebar_list.select_row(Some(&row));
            break;
        }
    }
    stack.set_visible_child_name(initial);

    window.present();
    Ok(())
}

fn rebuild_stack(
    stack: &gtk4::Stack,
    notes: &[Note],
    store: Arc<Store>,
    active: &str,
) {
    rebuild_stack_with_notes(stack, notes, store, active);
}

fn rebuild_stack_with_notes(
    stack: &gtk4::Stack,
    notes: &[Note],
    store: Arc<Store>,
    _active: &str,
) {
    // Clear existing pages
    while let Some(child) = stack.first_child() {
        stack.remove(&child);
    }

    // All
    let all_scroll = build_note_list(notes, None, store.clone());
    stack.add_named(&all_scroll, Some("all"));

    // Upcoming
    let upcoming_view = views::upcoming::build(notes);
    stack.add_named(&upcoming_view, Some("upcoming"));

    // Per-type
    for type_name in NoteType::all_builtin() {
        let nt = NoteType::from_str(type_name);
        let filtered: Vec<Note> = notes
            .iter()
            .filter(|n| n.note_type == nt && !n.done)
            .cloned()
            .collect();
        let scroll = build_note_list(&filtered, None, store.clone());
        stack.add_named(&scroll, Some(type_name));
    }

    // Archive
    let archive_view = views::archive::build(notes);
    stack.add_named(&archive_view, Some("archive"));
}

fn build_note_list(
    notes: &[Note],
    _sort: Option<&str>,
    store: Arc<Store>,
) -> gtk4::ScrolledWindow {
    let scroll = gtk4::ScrolledWindow::builder()
        .hscrollbar_policy(gtk4::PolicyType::Never)
        .vscrollbar_policy(gtk4::PolicyType::Automatic)
        .vexpand(true)
        .build();

    let list = gtk4::Box::builder()
        .orientation(gtk4::Orientation::Vertical)
        .spacing(4)
        .margin_top(8)
        .margin_bottom(8)
        .build();

    let mut sorted: Vec<Note> = notes.iter().filter(|n| !n.done).cloned().collect();
    sorted.sort_by(|a, b| b.created.cmp(&a.created));

    if sorted.is_empty() {
        list.append(
            &gtk4::Label::builder()
                .label("No notes here yet.")
                .margin_top(32)
                .build(),
        );
    } else {
        for note in &sorted {
            let card = build_note_card(note, store.clone());
            list.append(&card);
        }
    }

    scroll.set_child(Some(&list));
    scroll
}

fn build_note_card(note: &Note, store: Arc<Store>) -> gtk4::Box {
    let card = gtk4::Box::builder()
        .orientation(gtk4::Orientation::Vertical)
        .spacing(4)
        .margin_start(8)
        .margin_end(8)
        .margin_top(4)
        .margin_bottom(4)
        .css_classes(["note-card"])
        .build();

    let top_row = gtk4::Box::builder()
        .orientation(gtk4::Orientation::Horizontal)
        .spacing(8)
        .build();

    let body_label = gtk4::Label::builder()
        .label(&note.body)
        .hexpand(true)
        .xalign(0.0)
        .wrap(true)
        .build();

    let type_chip = gtk4::Label::builder()
        .label(note.note_type.as_str())
        .css_classes(["type-chip"])
        .build();

    top_row.append(&body_label);
    top_row.append(&type_chip);

    let bottom_row = gtk4::Box::builder()
        .orientation(gtk4::Orientation::Horizontal)
        .spacing(8)
        .build();

    let created_str = {
        let local: chrono::DateTime<chrono::Local> = note.created.into();
        local.format("%b %d %H:%M").to_string()
    };
    let meta_label = gtk4::Label::builder()
        .label(&created_str)
        .css_classes(["dim-label"])
        .xalign(0.0)
        .build();

    if let Some(ws) = &note.workspace {
        let ws_label = gtk4::Label::builder()
            .label(&format!("ws:{}", ws))
            .css_classes(["type-chip"])
            .build();
        bottom_row.append(&ws_label);
    }
    if note.rrule.is_some() {
        let rec_label = gtk4::Label::builder()
            .label("↻")
            .css_classes(["type-chip"])
            .build();
        bottom_row.append(&rec_label);
    }

    let spacer = gtk4::Box::builder().hexpand(true).build();
    bottom_row.append(&meta_label);
    bottom_row.append(&spacer);

    // Done button
    let done_btn = gtk4::Button::builder().label("✓").build();
    let note_id = note.id.clone();
    let store_clone = store.clone();
    let card_clone = card.clone();
    done_btn.connect_clicked(move |_| {
        if let Ok(Some(mut n)) = store_clone.get_by_id(&note_id) {
            n.mark_done();
            if let Err(e) = store_clone.update_note(&n) {
                tracing::error!("failed to mark done: {}", e);
            }
        }
        // Hide the card immediately
        card_clone.set_visible(false);
    });
    bottom_row.append(&done_btn);

    // Edit popover
    let edit_btn = gtk4::Button::builder().label("✎").build();
    let note_clone = note.clone();
    let store_clone2 = store.clone();
    let body_label_clone = body_label.clone();

    edit_btn.connect_clicked(move |btn| {
        let popover = editor::build_editor_popover(
            &note_clone,
            store_clone2.clone(),
            {
                let body_label = body_label_clone.clone();
                move |updated: Note| {
                    body_label.set_label(&updated.body);
                }
            },
        );
        popover.set_parent(btn);
        popover.popup();
    });
    bottom_row.append(&edit_btn);

    card.append(&top_row);
    card.append(&bottom_row);
    card
}

fn apply_css(_cfg: &Config) {
    let palette = load_palette();
    let user_css = std::fs::read_to_string(breadpad_shared::config::style_css_path()).ok();
    let css = build_css(&palette, user_css.as_deref());

    let provider = gtk4::CssProvider::new();
    provider.load_from_string(&css);
    gtk4::style_context_add_provider_for_display(
        &gtk4::gdk::Display::default().unwrap(),
        &provider,
        gtk4::STYLE_PROVIDER_PRIORITY_APPLICATION,
    );
}
