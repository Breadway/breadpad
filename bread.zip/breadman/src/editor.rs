use breadpad_shared::{
    store::Store,
    types::{Note, NoteType},
};
use gtk4::prelude::*;
use std::sync::Arc;

pub fn build_editor_popover(note: &Note, store: Arc<Store>, on_save: impl Fn(Note) + 'static) -> gtk4::Popover {
    let popover = gtk4::Popover::new();
    popover.set_has_arrow(false);

    let vbox = gtk4::Box::builder()
        .orientation(gtk4::Orientation::Vertical)
        .spacing(8)
        .margin_top(12)
        .margin_bottom(12)
        .margin_start(12)
        .margin_end(12)
        .width_request(400)
        .build();

    let body_entry = gtk4::Entry::builder()
        .text(&note.body)
        .hexpand(true)
        .build();

    let type_combo = gtk4::DropDown::from_strings(NoteType::all_builtin());
    let current_idx = NoteType::all_builtin()
        .iter()
        .position(|&s| s == note.note_type.as_str())
        .unwrap_or(3) as u32;
    type_combo.set_selected(current_idx);

    let time_label = gtk4::Label::builder()
        .label(
            &note
                .time
                .map(|t| {
                    let local: chrono::DateTime<chrono::Local> = t.into();
                    local.format("%Y-%m-%d %H:%M").to_string()
                })
                .unwrap_or_default(),
        )
        .xalign(0.0)
        .build();

    let rrule_entry = gtk4::Entry::builder()
        .text(note.rrule.as_ref().map(|r| r.as_str()).unwrap_or(""))
        .placeholder_text("RRULE (optional)")
        .build();

    let btn_row = gtk4::Box::builder()
        .orientation(gtk4::Orientation::Horizontal)
        .spacing(8)
        .build();

    let save_btn = gtk4::Button::builder()
        .label("Save")
        .css_classes(["confirm-button"])
        .build();

    let note_clone = note.clone();
    let popover_clone = popover.clone();
    let body_entry_c = body_entry.clone();
    let type_combo_c = type_combo.clone();
    let rrule_entry_c = rrule_entry.clone();

    save_btn.connect_clicked(move |_| {
        let mut updated = note_clone.clone();
        updated.body = body_entry_c.text().to_string();
        let type_idx = type_combo_c.selected() as usize;
        updated.note_type = NoteType::from_str(
            NoteType::all_builtin()
                .get(type_idx)
                .copied()
                .unwrap_or("note"),
        );
        let rrule_text = rrule_entry_c.text().to_string();
        updated.rrule = if rrule_text.trim().is_empty() {
            None
        } else {
            Some(breadpad_shared::types::RecurrenceRule::new(rrule_text))
        };

        if let Err(e) = store.update_note(&updated) {
            tracing::error!("failed to update note: {}", e);
        } else {
            on_save(updated);
        }
        popover_clone.popdown();
    });

    btn_row.append(&save_btn);

    vbox.append(&gtk4::Label::builder().label("Body").xalign(0.0).build());
    vbox.append(&body_entry);
    vbox.append(&gtk4::Label::builder().label("Type").xalign(0.0).build());
    vbox.append(&type_combo);
    if note.time.is_some() {
        vbox.append(&gtk4::Label::builder().label("Time").xalign(0.0).build());
        vbox.append(&time_label);
    }
    vbox.append(&gtk4::Label::builder().label("Recurrence").xalign(0.0).build());
    vbox.append(&rrule_entry);
    vbox.append(&btn_row);

    popover.set_child(Some(&vbox));
    popover
}
